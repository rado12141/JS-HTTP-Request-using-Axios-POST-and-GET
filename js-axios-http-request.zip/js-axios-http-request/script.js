var getBtn = document.getElementById('GetBtn')
var postBtn = document.getElementById('PostBtn')
var responseField = document.getElementById('response-field')


/**
 * AXIOS GET METHOD
 * @ axios.get(URL,[config])
 */

getBtn.addEventListener('click', function(e){
    responseField.innerHTML = `HTTP Request using Axios GET Method is on process...`;
    axios.get("data.json",{})
    .then(response => {
        setTimeout(()=>{
            // Delaying the Response to Display for 2 seconds
            responseField.innerHTML = JSON.stringify(response, null, 3)
        }, 2000)
    })
    .catch(error => {
        console.error(error)
        responseField.innerHTML = JSON.stringify(error, null, 3)
        
    })
})

/**
 * AXIOS POST METHOD
 * @ axios.post(URL, data,[config])
 */

postBtn.addEventListener('click', function(e) {
    responseField.innerHTML = `HTTP Request using Axios POST Method is on process...`;
    var formData = new FormData();
    formData.append("name", "Mark Cooper")
    formData.append("email", "mcooper@mail.com")
    formData.append("address", "Lot 14 Block 23, 6 St, Here City, Overthere")
    axios.post("post-api.php", formData, {
        "headers": {"content-type": 'application/x-www-form-urlencoded'},
        "responseType":'json'
    })
    .then(response => {
        setTimeout(()=>{
            // Delaying the Response to Display for 2 seconds
            responseField.innerHTML = JSON.stringify(response, null, 3)
        }, 2000)
    })
    .catch(error => {
        console.error(error)
        responseField.innerHTML = JSON.stringify(error, null, 3)
        
    })

})